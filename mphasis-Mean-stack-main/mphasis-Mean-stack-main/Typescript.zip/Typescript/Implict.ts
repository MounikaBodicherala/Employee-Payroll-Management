class MyClass{

id;//implict any data type
//id:any;//explict any data type
constructor(id:any){
this.id=id;

}


}

var mc=new MyClass(10);
console.log(mc.id);