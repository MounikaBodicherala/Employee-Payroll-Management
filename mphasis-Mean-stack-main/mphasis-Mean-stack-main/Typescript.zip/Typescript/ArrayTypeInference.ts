const numbers = [1, 2, 3]; // inferred to type number[]
numbers.push(4); // no error
numbers.push("Sabbir"); // Error
let first: number = numbers[0]; // no error