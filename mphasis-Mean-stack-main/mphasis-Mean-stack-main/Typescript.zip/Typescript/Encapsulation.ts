class Encapsulation{
empId:number;
private empSalary:number;
constructor(empId:number,empSalary:number){
this.empId=empId
this.empSalary=empSalary
}
//to access property empSalary
getEmpSalary():number{
    return this.empSalary;
}
}
var e=new Encapsulation(101,45000);
console.log("Emp Id:"+e.empId);
//console.log("Emp Salary:"+e.empSalary);//error
console.log(e.getEmpSalary());