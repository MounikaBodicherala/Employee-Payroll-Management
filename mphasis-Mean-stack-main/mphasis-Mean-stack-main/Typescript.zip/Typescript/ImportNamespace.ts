import { Supernamespace } from "./namespace";
let subclass=new Supernamespace.SubClass();
subclass.display();