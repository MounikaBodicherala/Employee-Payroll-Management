export namespace Supernamespace{
export class Super{
a:number=10;
getA():number{
    return this.a;
}
}
export class SubClass extends Super{
a:number=20;
display():void{
console.log("access:"+this.a);
console.log("access:"+super.getA());
}
}
}