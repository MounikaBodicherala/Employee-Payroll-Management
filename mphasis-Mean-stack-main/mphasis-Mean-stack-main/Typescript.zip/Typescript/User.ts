class User{
 username:string;
 password:string;
 firstname:string;
 lastname:string;
 email?:string;

 constructor(username:string,password:string,firstname:string,lastname:string,
   email?:string){
    this.username=username;
    this.password=password;
    this.lastname=lastname;
    
 }

}
let user=new User("sabbirp","sabbir123","sabbir","poonawala");
