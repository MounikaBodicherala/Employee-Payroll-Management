class Employee{ 
   //field 
   empId:number;
   empName:string;
   empSalary:number;
   empDesignation:string; 
   //constructor 
   constructor(empId:number,empName:string,empSalary:number
      ,empDesignation:string) { 
this.empId = empId
this.empName=empName
this.empSalary=empSalary
this.empDesignation=empDesignation
   }

displayEmployeeData():void{
console.log("Emp Id:"+this.empId);
console.log("Emp Name:"+this.empName);
console.log("Emp Salary:"+this.empSalary);
console.log("Emp Designation:"+this.empDesignation);
}  
computeTax():number{
return this.empSalary*0.01;
}
} 
var employee=new Employee(101,"Sabbir",45000,"Trainer");
employee.displayEmployeeData();
console.log("Tax:"+ employee.computeTax());

