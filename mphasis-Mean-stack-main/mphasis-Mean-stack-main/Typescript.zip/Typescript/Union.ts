let empCode:number | string;
empCode=1001;
empCode="SE1001";
console.log("Emp Code:"+empCode);