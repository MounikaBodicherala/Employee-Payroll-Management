function genericMethod<S, T>(param1: S, param2: T): [S, T] {
    return [param1, param2];
  }
  console.log(genericMethod<string, number>('Sabbir', 101));
  //console.log(genericMethod<string, number>('Sabbir', "101"));
  console.log(genericMethod<string, boolean>('Sabbir', true));
  console.log(genericMethod<string, Date>('Sabbir', new Date()));
  