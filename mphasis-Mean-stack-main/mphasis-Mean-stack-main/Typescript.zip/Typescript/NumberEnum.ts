enum HttpStatusCodes {
  NotFound = 404,
  Success = 200,
  Created=201
}
// logs 404
console.log(HttpStatusCodes.NotFound);
// logs 201
console.log(HttpStatusCodes.Created);