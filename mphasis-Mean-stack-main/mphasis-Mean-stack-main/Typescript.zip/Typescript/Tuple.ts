
let tuple: [number, boolean, string];


tuple = [5, false, 'TypeScript'];
//tuple=['TypeScript',false,5];