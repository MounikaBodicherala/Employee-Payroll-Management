function reverseArray<T>(array: T[]): T[] {
  return array.reverse();
}

const numbers: number[] = [1, 2, 3, 4, 5];
const reversedNumbers: number[] = reverseArray(numbers);
console.log(reversedNumbers);

const names: string[] = ["John", "Jane", "Alice"];
const reversedNames: string[] = reverseArray(names);
console.log(reversedNames);