class DateClass{
date:Date;
constructor(){
this.date=new Date();
}
print():void{
console.log("Date is :"+this.date);
}
}
let dateClass=new DateClass();
dateClass.print();