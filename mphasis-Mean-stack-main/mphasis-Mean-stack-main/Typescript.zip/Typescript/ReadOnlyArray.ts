const names: readonly string[] = ["Sabbir"];
names.push("Amit"); //error