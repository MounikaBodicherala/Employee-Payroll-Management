enum Color {
  Red = 'Red',
  Green = "Green",
  Blue = "Blue"
};
// logs "Red"
console.log(Color.Red);
// logs "Blue"
console.log(Color.Blue);