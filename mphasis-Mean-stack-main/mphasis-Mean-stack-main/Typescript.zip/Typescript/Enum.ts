enum ComputerStates {
  ON,
  OFF,
  SUSPEND
}
let currentState = ComputerStates.ON;
// logs 0
console.log(currentState);
//currentState = 'OFF'; error