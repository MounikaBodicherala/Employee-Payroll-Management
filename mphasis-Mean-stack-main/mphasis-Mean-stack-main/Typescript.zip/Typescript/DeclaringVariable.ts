var empId:number=1001;
var empName:string="Sabbir";
var empSalary:number=45000;
var empDesignation:string="Trainer";

console.log("Emp Id:"+empId);
console.log("Emp Name:"+empName);
console.log("Emp Salary:"+empSalary);
console.log("Emp Designation:"+empDesignation);

