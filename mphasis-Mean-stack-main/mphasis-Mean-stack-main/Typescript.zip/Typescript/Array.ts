const names: string[] = [];
names.push("Sabbir"); // no error
names.push("Amit");
names.push("Pranjali");
names.push("Sumeet");
//names.push(3); // Error:
console.log("pop->"+names.pop());
console.log(names);