let greeting:string;
greeting="HelloWorld";
console.log(greeting);