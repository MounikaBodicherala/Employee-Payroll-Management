class StaticDemo{

static x1:number=12;
static x():void{

console.log("Static function called");

}



}

console.log("x1:"+StaticDemo.x1);
StaticDemo.x();