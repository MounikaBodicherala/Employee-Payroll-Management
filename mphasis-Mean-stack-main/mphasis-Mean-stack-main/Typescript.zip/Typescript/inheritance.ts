class Figure{
area:number=0;
protected computeArea():number{
return 0;
}
}
class Square extends Figure{
length:number;
constructor(length:number){
super();
this.length=length;
}
computeArea():number{
return this.length*this.length;
}
displayArea():void{
console.log("Area in Figure:"+super.computeArea());
}
}
class Rectangle extends Figure{
    length:number;
    breadth:number;
    constructor(length:number,breadth:number){
    super();
    this.length=length;
    this.breadth=breadth;
    }
    computeArea():number{
    return this.length*this.breadth;
    }
    displayArea():void{
    console.log("Area in Figure:"+super.computeArea());
    }
    }
var square=new Square(10);
console.log("Area of square is :"+square.computeArea());
square.displayArea();
var rectangle=new Rectangle(10,20);
console.log("Area of Rectangle is:"+rectangle.computeArea());
rectangle.displayArea();