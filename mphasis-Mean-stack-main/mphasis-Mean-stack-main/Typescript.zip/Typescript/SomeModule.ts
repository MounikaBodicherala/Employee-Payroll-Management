declare module "SomeModule" {
    export function fn(): string;
}