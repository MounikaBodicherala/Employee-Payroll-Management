import { Component } from '@angular/core';

@Component({
  selector: 'app-ng-style-directive',
  templateUrl: './ng-style-directive.component.html',
  styleUrls: ['./ng-style-directive.component.css']
})
export class NgStyleDirectiveComponent {
  getColor(country) { 
    switch (country) {
      case 'IN':
        return 'green';
      case 'USA':
        return 'blue';
      case 'UK':
        return 'red';
    }
  }
  people: any[] = [
    {
      "name": "Sabbir Poonawala",
      "country": 'IN'
    },
    {
      "name": "John Smith",
      "country": 'USA'
    },
    {
      "name": "John Bayor",
      "country": 'UK'
    },
    {
      "name": "Aguirre  Ellis",
      "country": 'UK'
    },
    {
      "name": "Amit Patel",
      "country": 'IN'
    }
  ];
}
