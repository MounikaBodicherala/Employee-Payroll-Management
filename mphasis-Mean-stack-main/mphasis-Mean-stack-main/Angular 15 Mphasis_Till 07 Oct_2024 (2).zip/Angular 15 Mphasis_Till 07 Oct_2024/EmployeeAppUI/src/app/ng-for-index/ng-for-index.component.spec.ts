import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NgForIndexComponent } from './ng-for-index.component';

describe('NgForIndexComponent', () => {
  let component: NgForIndexComponent;
  let fixture: ComponentFixture<NgForIndexComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NgForIndexComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NgForIndexComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
