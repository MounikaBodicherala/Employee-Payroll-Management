import { Component } from '@angular/core';

@Component({
  selector: 'app-ng-for-index',
  templateUrl: './ng-for-index.component.html',
  styleUrls: ['./ng-for-index.component.css']
})
export class NgForIndexComponent {
items:string[]=["sabbir","amit","rohit","sachin"];
}
