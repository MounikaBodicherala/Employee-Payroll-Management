import { Component } from '@angular/core';
import { Student } from '../model/Student';

@Component({
  selector: 'app-attribute-directive',
  templateUrl: './attribute-directive.component.html',
  styleUrls: ['./attribute-directive.component.css']
})
export class AttributeDirectiveComponent {
  students:Student[]=[
    {"rollNo":1001,"scores":79},
    {"rollNo":1002,"scores":59},
    {"rollNo":1003,"scores":80},
    {"rollNo":1004,"scores":61},
    {"rollNo":1005,"scores":62},
    {"rollNo":1006,"scores":70},
    {"rollNo":1007,"scores":75},
  ]
  getClassOf(val) {
    if (val > 50 && val < 60) {
      return 'secondclass';
    } else if (val > 60 && val < 70) {
      return 'firstclass';
    } else {
      return 'distinctionclass'
    }
  }
}
