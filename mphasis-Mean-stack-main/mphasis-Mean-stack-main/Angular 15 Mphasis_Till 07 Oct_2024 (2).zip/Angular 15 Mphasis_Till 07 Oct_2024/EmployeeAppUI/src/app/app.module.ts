import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from "@angular/common/http";
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { DisplayEmployeeComponent } 
from './display-employee/display-employee.component';
import { DataBindingComponent } from './data-binding/data-binding.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { CalculatorComponent } from './calculator/calculator.component';
import { AttributeDirectiveComponent } from './attribute-directive/attribute-directive.component';
import { SwitchDirectiveComponent } from './switch-directive/switch-directive.component';
import { IfComponent } from './if/if.component';
import { NgStyleDirectiveComponent } from './ng-style-directive/ng-style-directive.component';
import { CustomDirectiveComponent } from './custom-directive/custom-directive.component';
import { HighlightDirectiveDirective } from './highlight-directive.directive';
import { NgForIndexComponent } from './ng-for-index/ng-for-index.component';

@NgModule({
  declarations: [
    AppComponent,
    DisplayEmployeeComponent,
    DataBindingComponent,
    ParentComponent,
    ChildComponent,
    CalculatorComponent,
    AttributeDirectiveComponent,
    SwitchDirectiveComponent,
    IfComponent,
    NgStyleDirectiveComponent,
    CustomDirectiveComponent,
    HighlightDirectiveDirective,
    NgForIndexComponent
 
  ],
 
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
