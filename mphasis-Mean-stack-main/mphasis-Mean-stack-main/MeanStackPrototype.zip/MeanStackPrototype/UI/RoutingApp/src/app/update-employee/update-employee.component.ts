import { Component } from '@angular/core';
import { Employee } from '../model/Employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css']
})
export class UpdateEmployeeComponent {
  employee: Employee = new Employee();
  submitted = false;

employees:Employee[];

constructor(private employeeService: EmployeeService) {
this.employee.empId=employeeService.getEmpId();
this.employeeService.getEmployeeById(this.employee)
.subscribe( data => {
  this.employees = data[0];
  console.log(data);
  this.employee.empId=data[0]['empId'];
  this.employee.empName=data[0]['empName'];
  this.employee.empSalary=data[0]['empSalary'];
  this.employee.empDesignation=data[0]['empDesignation'];
});
   }

  ngOnInit() {
  }

  updateEmployee(): void {
    this.submitted = false;
    this.employee = new Employee();
  }
  update() {
    this.employeeService.updateEmployee(this.employee)
      .subscribe(data => console.log(data), error => console.log(error));
    this.employee = new Employee();
  }
  onSubmit() {
    this.submitted = true;
    this.update();
  }
}
