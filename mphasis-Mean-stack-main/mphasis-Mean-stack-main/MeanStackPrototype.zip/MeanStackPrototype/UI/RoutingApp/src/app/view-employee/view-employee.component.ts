import { Component } from '@angular/core';
import { Employee } from '../model/Employee';
import { Router } from '@angular/router';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-view-employee',
  templateUrl: './view-employee.component.html',
  styleUrls: ['./view-employee.component.css']
})
export class ViewEmployeeComponent {

  employees: Employee[];
  constructor(private employeeService: EmployeeService) {
    this.employeeService.getEmployees()
    .subscribe( data => {
      this.employees = data;
    });
 
    
  }
}
