var express = require('express');
const dotenv = require('dotenv');
var bodyParser = require('body-parser')

dotenv.config({ path: './.env' });
// create application/json parser
var jsonParser = bodyParser.json()
 
// create application/x-www-form-urlencoded parser
var urlencodedParser = bodyParser.urlencoded({ extended: false })
const cors = require('cors')

var app = express();
app.use(cors())
app.set('view engine', 'pug')
app.set('views', './views')
var mongoose = require('mongoose');
mongoose.connect('mongodb://0.0.0.0:27017/EmployeesDB');

var employeeSchema = mongoose.Schema({
empId: Number,
empName: String,
empSalary: Number,
empDesignation: String
});
var Employee = mongoose.model("employee", employeeSchema);

app.get('/register', function(req, res){
res.render('employee');
});

app.get('/employee', function(req, res){
Employee.find().then((response)=>{
    res.send(response);
}).catch((error)=>{
    console.log(error);
});
});


app.post('/employee',jsonParser, function(req, res){
    console.log(req.method);
var employeeInfo = req.body; //Get the parsed information
console.log(req.body);
if(!employeeInfo.empId || !employeeInfo.empName || !employeeInfo.empSalary || !employeeInfo.empDesignation){
res.render('show_message', {
message: "Sorry, you provided worng info", type: "error"});
} else {
var newEmployee = new Employee({
empId: employeeInfo.empId,
empName: employeeInfo.empName,
empSalary: employeeInfo.empSalary,
empDesignation:employeeInfo.empDesignation
});
newEmployee.save().then((response)=>{
    res.send(response);
}).catch((error)=>{
    console.log(error);
});
}
});

app.put('/employee/:id', urlencodedParser,function(req, res){
Employee.findOneAndUpdate({"empId":req.params.id}, req.body, function(err, response){
console.log(req.body);
    if(err) res.json({message: "Error in updating employee with id " + req.params.id});
res.json(response);
});
});

app.get('/employee/:id', function(req, res){
    console.log("Id:"+req.params.id);
    Employee.find({"empId":req.params.id}).then((response)=>{
        res.send(response);
    }).catch((error)=>{
        res.send(error);
    });
    });

app.delete('/employee/:id', function(req, res){
Employee.findOneAndDelete({"empId":req.params.id}, function(err, response){
if(err) res.json({message: "Error in deleting record id " + req.params.id});
else res.json({message: "Employee with id " + req.params.id + " removed."});
});
});
var server = app.listen(process.env.PORT, function () {
var host = server.address().address
var port = server.address().port
console.log("Example app listening at http://%s:%s"
    , host, port)
})