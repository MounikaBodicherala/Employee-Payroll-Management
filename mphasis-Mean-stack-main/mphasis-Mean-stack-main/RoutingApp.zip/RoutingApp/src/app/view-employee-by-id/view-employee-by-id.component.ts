import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-view-employee-by-id',
  templateUrl: './view-employee-by-id.component.html',
  styleUrl: './view-employee-by-id.component.css'
})
export class ViewEmployeeByIdComponent {

  
  constructor(route:ActivatedRoute){
    console.log(route.snapshot.paramMap.get('id'));

  }
}
