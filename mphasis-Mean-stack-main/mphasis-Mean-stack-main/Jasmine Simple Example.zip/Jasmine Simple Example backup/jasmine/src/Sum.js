function sum(no1,no2){
    if(no1>1000 || no2>1000){
        throw new Error('Error');
    }
    return no1+no2;
}