
describe("Test add ",function(){
    it("Given positive test data",function(){
        var expected=15;
        var actual=sum(10,5);
        expect(expected).toBe(actual);
    });
    it("Given negative test data",function(){
        var expected=15;
        try{
        var actual=sum(1001,5);
    }catch(e){
        expect(true).toBe(true);
        expect(e.message).toBe("Error");
    }
        
    });
    });