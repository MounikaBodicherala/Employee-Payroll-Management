import { Component, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import {
  ChartType,
  Column,
  GoogleChartComponent
} from 'angular-google-charts';
@Component({
  selector: 'app-pie-chart',
  templateUrl: './pie-chart.component.html',
  styleUrls: ['./pie-chart.component.css']
})
export class PieChartComponent {
  title = 'google-charts-angular-example';
  public charts: {
    title: string;
    type: ChartType;
    data: any[][];
    columns?: Column[];
    options?: {};
  }[] = [];
  @ViewChild('chart', { static: true })
  public chart!: GoogleChartComponent;

  constructor(private router: Router) {
  
    this.charts.push({
    title: 'Pie Chart',
    type: ChartType.PieChart,
    columns: ['Task', 'Hours per Day'],
    data: [
      ['Work', 11],
      ['Eat', 2],
      ['Commute', 2],
      ['Watch TV', 2],
      ['Sleep', 7]
    ]
  });
}
public ngOnInit() {
  console.log(this.chart);
}
}
