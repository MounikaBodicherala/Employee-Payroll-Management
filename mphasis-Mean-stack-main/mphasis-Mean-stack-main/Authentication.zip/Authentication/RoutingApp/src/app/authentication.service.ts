import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {User} from './model/User';
import { first } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private http:HttpClient) { }
  authenticateURL:string="http://localhost:8083/authenticate/users";
  user: User;
  authenticated:boolean;
  users: User[];
  userBackend:User;

  authenticate(username, password) {
   
    this.user=new User();
    this.user.username=username;
    this.user.password=password;
   this.getUser(this.user).pipe(first()).subscribe((data)=>{
    console.log("in subscribe:"+data[0].username);
    console.log("in subscribe:"+data[0].password);
    console.log("User:"+this.user.username);
    console.log("User:"+this.user.password);
     this.userBackend=new User();
     this.userBackend.username=data[0].username;
     this.userBackend.password=data[0].password;
     this.userBackend.role=data[0].role;
     
   });
   if(this.user.username===this.userBackend.username && this.user.password==this.userBackend.password){
     this.authenticated=true;
     console.log("Authenticated:"+this.authenticated);
     sessionStorage.setItem('username', username);
      sessionStorage.setItem('role',this.userBackend.role);
   }else{
     this.authenticated=false;

   }

   return this.authenticated;
 }

 getUser(User){
   return this.http.post<User>(this.authenticateURL, User);
 }

 isUserLoggedIn() {
   let user = sessionStorage.getItem('username')
   let role=sessionStorage.getItem('role');
   console.log(!(user === null))
   return !(user === null && role===null);
 }
 isUserAdmin(){
   let role=sessionStorage.getItem('role');
   return (role==='admin');
 }
 isUserNotAdmin(){
   let role=sessionStorage.getItem('role');
   return (role==='user');
 }

 logOut() {
   sessionStorage.removeItem('username')
   sessionStorage.removeItem('role')
   sessionStorage.clear();
  localStorage.clear();

 }

}
