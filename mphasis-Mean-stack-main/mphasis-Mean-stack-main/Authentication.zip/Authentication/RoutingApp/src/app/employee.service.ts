import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Employee} from './model/Employee';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  empId:number=0;

 public retrieveEmployeesURL = 'http://localhost:8083/employee';
 private registerEmployeesURL='http://localhost:8083/employee';
 private updateEmployeeURL='http://localhost:8083/employee';
 private retrieveEmployeeByIdURL='http://localhost:8083/employee';
 private deleteEmployeeByIdURL='http://localhost:8083/employee';

constructor(private http:HttpClient) { }
  
public getEmployeeById(employee:Employee){
    this.empId=employee.empId;
  return this.http.get<Employee>(this.retrieveEmployeeByIdURL+'/'+employee.empId);
  }
  
  public getEmployees() {
    return this.http.get<Employee[]>(this.retrieveEmployeesURL);
  }
  public registerEmployee(employee:Employee) {
    return this.http.post<Employee>(this.registerEmployeesURL, employee);
  }
  public updateEmployee(employee:Employee){
    return this.http.put<Employee>(this.updateEmployeeURL+"/"+employee.empId,employee);
  }
  public deleteEmployee(employee:Employee){
    return this.http.delete<Employee>(this.deleteEmployeeByIdURL+"/"+employee.empId);
  }
  public getEmpId(){
    return this.empId;
  }
}
