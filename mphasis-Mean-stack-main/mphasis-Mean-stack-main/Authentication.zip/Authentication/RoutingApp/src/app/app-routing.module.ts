import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ViewEmployeeComponent } from './view-employee/view-employee.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';
import { ViewEmployeeByIdComponent } from './view-employee-by-id/view-employee-by-id.component';
import { DeleteEmployeeComponent } from './delete-employee/delete-employee.component';
import { AuthGaurdUserService } from './auth-gaurd-user.service';
import { AuthGaurdAdminService } from './auth-gaurd-admin.service';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';

const routes: Routes = [
  { path: 'getEmployees', component: ViewEmployeeComponent,canActivate:[AuthGaurdUserService] },
  { path: 'saveEmployee', component: AddEmployeeComponent,canActivate:[AuthGaurdAdminService]},
  { path: 'updateEmployee', component: UpdateEmployeeComponent,canActivate:[AuthGaurdAdminService] },
  { path: 'employee', component: ViewEmployeeByIdComponent,canActivate:[AuthGaurdAdminService] },
  { path: 'deleteEmployee', component: DeleteEmployeeComponent,canActivate:[AuthGaurdAdminService] },
  { path: 'login', component: LoginComponent },
  { path: 'logout', component: LogoutComponent }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
