import { Component } from '@angular/core';
import { Employee } from '../model/Employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-delete-employee',
  templateUrl: './delete-employee.component.html',
  styleUrls: ['./delete-employee.component.css']
})
export class DeleteEmployeeComponent {
  employee: Employee = new Employee();
  submitted = false;
  constructor(private employeeService: EmployeeService) {
    this.employee.empId=employeeService.getEmpId();
    console.log("emp id in constructor:"+this.employee.empId);
  }
  ngOnInit() {
  }

  delete() {
    console.log("delete called");
    console.log(this.employeeService);
    this.employeeService.deleteEmployee(this.employee)
      .subscribe(data => console.log(data), error => console.log(error));
    this.employee = new Employee();
  }

  onSubmit() {
    this.submitted = true;
    this.delete();
  }
}
