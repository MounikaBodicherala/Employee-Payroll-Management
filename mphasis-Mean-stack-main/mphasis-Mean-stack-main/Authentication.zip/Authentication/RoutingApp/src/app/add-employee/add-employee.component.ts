import { Component } from '@angular/core';
import { Employee } from '../model/Employee';
import { EmployeeService } from '../employee.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent {

  formData:any;
  employee: Employee = new Employee();
  submitted = false;
  text='Employee Form page';
  constructor(private employeeService: EmployeeService) { }

  ngOnInit(): void {

    this.formData=new FormGroup(
{
 empId: new FormControl("",Validators.compose(
   [
     Validators.required,
     Validators.minLength(5)
   ]
 )),
 empName:new FormControl("",Validators.compose(
   [
     Validators.required,
     Validators.pattern('[a-zA-Z]*')
   ]
 )),
 empSalary:new FormControl("",Validators.compose(
   [
     Validators.required,
     Validators.minLength(4)
   ]
 )),
 empDesignation:new FormControl("",Validators.compose(
   [
     Validators.required
   ]
 ))
}
);
  }


  newEmployee(): void {
    this.submitted = false;
    this.employee = new Employee();
  }
  save() {
    this.employeeService.registerEmployee(this.employee)
      .subscribe(data => console.log(data), error => console.log(error));
    this.employee = new Employee();
  }

  onSubmit(data:any) {
    this.submitted = true;
    this.employee.empId=data.empId;
    this.employee.empName=data.empName;
    this.employee.empSalary=data.empSalary;
    this.employee.empDesignation=data.empDesignation;
    this.save();
  }
  get empId():FormControl{
    return this.formData.get('empId');
  }
  get empName():FormControl{
    return this.formData.get('empName');
  }
  get empSalary():FormControl{
    return this.formData.get('empSalary');
  }
  get empDesignation():FormControl{
    return this.formData.get('empDesignation');
  }
  
}
