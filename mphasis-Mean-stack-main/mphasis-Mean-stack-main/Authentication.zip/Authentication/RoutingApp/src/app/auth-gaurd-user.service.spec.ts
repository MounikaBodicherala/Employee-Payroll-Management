import { TestBed } from '@angular/core/testing';

import { AuthGaurdUserService } from './auth-gaurd-user.service';

describe('AuthGaurdUserService', () => {
  let service: AuthGaurdUserService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AuthGaurdUserService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
