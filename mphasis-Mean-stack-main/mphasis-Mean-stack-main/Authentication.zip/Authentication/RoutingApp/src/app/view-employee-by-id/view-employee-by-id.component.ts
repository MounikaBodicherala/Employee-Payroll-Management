import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Employee } from '../model/Employee';
import { EmployeeService } from '../employee.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-view-employee-by-id',
  templateUrl: './view-employee-by-id.component.html',
  styleUrls: ['./view-employee-by-id.component.css']
})
export class ViewEmployeeByIdComponent {

  employee: Employee = new Employee();
  submitted = false;
  noRecordFound=false;
  empId:number;
  constructor(private employeeService: EmployeeService){
  }
  search() {
     this.employeeService.getEmployeeById(this.employee)
    .subscribe( data => {
      this.employee.empId=data[0].empId;
      this.employee.empName=data[0].empName;
      this.employee.empSalary=data[0].empSalary;
      this.employee.empDesignation=data[0].empDesignation;
    });
    if(this.employee.empId==0 || this.employee.empName===undefined){
      this.noRecordFound=true;
    }
  }
  async onSubmit() {
     this.submitted = true;
    await this.search();
    }

}
