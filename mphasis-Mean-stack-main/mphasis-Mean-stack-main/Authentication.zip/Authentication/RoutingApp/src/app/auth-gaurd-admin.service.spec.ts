import { TestBed } from '@angular/core/testing';

import { AuthGaurdAdminService } from './auth-gaurd-admin.service';

describe('AuthGaurdAdminService', () => {
  let service: AuthGaurdAdminService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AuthGaurdAdminService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
