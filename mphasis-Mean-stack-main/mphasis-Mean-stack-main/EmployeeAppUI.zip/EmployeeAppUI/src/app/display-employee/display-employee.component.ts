import { Component } 
from '@angular/core';
import { Employee } from '../model/Employee';

@Component({
  selector: 'app-display-employee',
  templateUrl: './display-employee.component.html',
  styleUrls: ['./display-employee.component.css']
})
export class DisplayEmployeeComponent {

  title:string="Display Employee Component";

  
  employees:Employee[]=[
    {"empId":1001,"empName":"Sabbir Poonawala","empSalary":45000,"empDesignation":"Trainer"},
    {"empId":1002,"empName":"Amit Kumar","empSalary":25000,"empDesignation":"Developer"},
    {"empId":1003,"empName":"Chirag Desai","empSalary":35000,"empDesignation":"Programmer"},
    {"empId":1004,"empName":"Rohit Agarwal","empSalary":40000,"empDesignation":"Programmer"},
    {"empId":1005,"empName":"Rachit Jain","empSalary":12000,"empDesignation":"Clerk"}
  ]
}
