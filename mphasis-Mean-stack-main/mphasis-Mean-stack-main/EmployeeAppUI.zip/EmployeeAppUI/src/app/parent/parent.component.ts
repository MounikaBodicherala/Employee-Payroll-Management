import { Component } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent {
  parentMessage:string = "Message from Parent";

  message: string;

  receiveMessage($event: string) {
    this.message = $event;
  }
}
