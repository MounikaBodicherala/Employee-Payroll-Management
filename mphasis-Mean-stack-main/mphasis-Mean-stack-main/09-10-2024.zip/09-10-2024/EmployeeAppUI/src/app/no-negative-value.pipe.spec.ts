import { NoNegativeValuePipe } from './no-negative-value.pipe';

describe('NoNegativeValuePipe', () => {
  it('create an instance', () => {
    const pipe = new NoNegativeValuePipe();
    expect(pipe).toBeTruthy();
  });
});
