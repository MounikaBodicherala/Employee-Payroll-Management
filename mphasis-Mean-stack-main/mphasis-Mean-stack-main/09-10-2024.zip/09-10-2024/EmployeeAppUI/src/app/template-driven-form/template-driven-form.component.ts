import { Component } from '@angular/core';
import { Employee } from '../model/Employee';

@Component({
  selector: 'app-template-driven-form',
  templateUrl: './template-driven-form.component.html',
  styleUrls: ['./template-driven-form.component.css']
})
export class TemplateDrivenFormComponent {
  employee:Employee=new Employee();
  onSubmit(){
    console.log("Emp Id:"+this.employee.empId);
    console.log("Emp Name:"+this.employee.empName);
    console.log("Emp Salary:"+this.employee.empSalary);
    console.log("Emp Designation:"+this.employee.empDesignation);
  }
  
}
