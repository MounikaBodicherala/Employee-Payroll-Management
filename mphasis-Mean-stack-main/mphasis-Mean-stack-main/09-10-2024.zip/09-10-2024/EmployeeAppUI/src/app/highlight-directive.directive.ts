import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[appHighlightDirective]'
})
export class HighlightDirectiveDirective {

  
  @Input('appHighlightDirective')
  colorInput:string;

  constructor(private el: ElementRef) {
   }
   
   @HostListener('mouseover')
   mouseOver(){
    this.changeBgColor(this.colorInput);
   }
   @HostListener('mouseout')
   mouseOut(){
    this.changeBgColor("yellow");
   }

   changeBgColor(color:string){
    this.el.nativeElement.style.backgroundColor=color;
   }

}
