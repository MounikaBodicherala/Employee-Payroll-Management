import { Component } from '@angular/core';
import { Student } from '../model/Student';

@Component({
  selector: 'app-pipe',
  templateUrl: './pipe.component.html',
  styleUrls: ['./pipe.component.css']
})
export class PipeComponent {
  fullname="sabbir poonawala";

  todaydate=new Date();
  

  pi:number=3.141592653589793;

  students:Student[]=[
    {"rollNo":1001,"scores":79},
    {"rollNo":1002,"scores":59},
    {"rollNo":1003,"scores":80},
    {"rollNo":1004,"scores":61},
    {"rollNo":1005,"scores":62},
    {"rollNo":1006,"scores":70},
    {"rollNo":1007,"scores":75},
  ]
}
