import { Component } from '@angular/core';

@Component({
  selector: 'app-calculator',
  templateUrl: './calculator.component.html',
  styleUrls: ['./calculator.component.css']
})
export class CalculatorComponent {
no1:string;
no2:string;
result:string;

add(){
  this.result=String(Number(this.no1)+Number(this.no2));
}
sub(){
  this.result=String( Number(this.no1)-Number(this.no2));
}
multi(){
  this.result=String( Number(this.no1)*Number(this.no2));
}
div(){
  this.result=String (Number(this.no1)/Number(this.no2));
}
}
