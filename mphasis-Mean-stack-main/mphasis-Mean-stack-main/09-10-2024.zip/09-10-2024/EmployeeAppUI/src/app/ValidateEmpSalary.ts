import { AbstractControl } from '@angular/forms';

export function ValidateEmpSalary(control: AbstractControl) {
  if (control.value<0) {
    return { invalidempSalary: true };
  }
  return null;
}