import { SQRTPipe } from './sqrt.pipe';

describe('SQRTPipe', () => {
  it('create an instance', () => {
    const pipe = new SQRTPipe();
    expect(pipe).toBeTruthy();
  });
});
