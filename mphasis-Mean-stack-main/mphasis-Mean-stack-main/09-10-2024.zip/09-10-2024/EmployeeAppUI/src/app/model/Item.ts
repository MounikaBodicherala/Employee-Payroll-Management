class Item {
    countryCode: number;
    countryName: string;
}