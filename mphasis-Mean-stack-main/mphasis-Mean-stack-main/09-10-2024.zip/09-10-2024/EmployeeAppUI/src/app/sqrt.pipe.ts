import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sQRT'
})
export class SQRTPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    return   Math.sqrt(value);
    ;
  }

}
