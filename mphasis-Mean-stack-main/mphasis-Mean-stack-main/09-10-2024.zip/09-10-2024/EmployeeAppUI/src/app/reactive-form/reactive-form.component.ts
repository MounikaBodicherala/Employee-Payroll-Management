import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import {ValidateEmpSalary} from '../ValidateEmpSalary';
@Component({
  selector: 'app-reactive-form',
  templateUrl: './reactive-form.component.html',
  styleUrls: ['./reactive-form.component.css']
})
export class ReactiveFormComponent implements OnInit{
  formData;

  constructor() { }

  ngOnInit(): void {

    this.formData=new FormGroup(
{
 empId: new FormControl("",Validators.compose(
   [Validators.required,
   Validators.minLength(5)]
 )),
 empName:new FormControl("",Validators.compose(
   [
     Validators.required,
     Validators.pattern('[a-zA-Z]*')
   ]
 )),
 empSalary:new FormControl("",Validators.compose(
   [
     Validators.required,
     Validators.minLength(4),
     ValidateEmpSalary
   ]
 )),
 empDesignation:new FormControl("",Validators.compose(
   [
     Validators.required
     
   ]
 ))
},
);
  }

  formSubmit(data){

console.log("Emp Id:"+data.empId);
console.log("Emp Name:"+data.empName);
console.log("Emp Salary:"+data.empSalary);
console.log("Emp Designation:"+data.empDesignation);

}
get empId():FormControl{

  return this.formData.get('empId');
}

get empName():FormControl{

  return this.formData.get('empName');
}

get empDesignation():FormControl{

  return this.formData.get('empDesignation');
}

get empSalary():FormControl{

  return this.formData.get('empSalary');
}

}
